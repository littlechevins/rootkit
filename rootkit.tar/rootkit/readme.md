Put ./install script in this directory
Install script will generate elevate binary which will also be placed here
